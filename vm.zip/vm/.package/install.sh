sudo apt install qemu-system && qemu-img create -f qcow2 disco 14G && qemu-system-x86_64 -smp 2 -m 6G -cdrom
file.iso -drive file=disco -vnc localhost:1 && ngrok tcp 5901