import time
import os
from xqlnet import cores
from sys import platform
#Comandos

def exit():
 os.system('exit')

def ngrok():
 os.system('cd .package && bash ngrok.sh')

def iniciar():
 os.system('cd .package && bash iniciar.sh')

def install():
 os.system('cd .package && bash install.sh')

def dwd():
 os.system('cd mediafire_dl && python3 Dowload.py')

def up():
 os.system('sudo apt update')

def clear():
 os.system('clear')

clear()
user = input('Digite Seu login:  ')

clear()
#configurações do título
def linha(tam=42):
    return '-' * tam

def TL3(txt):
    print(linha())
    print(txt.center(42))
    print(linha())

TL3('Menu')
#Opções do menu
print('''  
           [ 1 ] INICIA MQNVT
           [ 2 ] INSTALAR MQNVT
           [ 3 ] NGROK
           [ 4 ] BAIXAR ISO
           [ 5 ] ATUALIZAR PACOTES
           [ 6 ] GOOGLE SHELL WEB
           [ 0 ] SAIR DA SCRIPT
                                  
                             ''')

option = int(input("~/  "))

print()
                             
#codigo python das opções

if option == 1:
   iniciar()
elif option == 2:
     install()
elif option == 3:
     ngrok()
elif option == 4:
     dwd()
elif option == 5:
     up()
elif option == 6:
     print("Site web: https://console.cloud.google.com/")
elif option == 0:
     clear()
     exit()
