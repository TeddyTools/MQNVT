import mediafire_dl

url = 'xxx'
output = 'file.zip'
mediafire_dl.download(url, output, quiet=False)